A Pen created at CodePen.io. You can find this one at http://codepen.io/TeamiHackify/pen/BKaeWM.

 Auto Code Typer By @TeamiHackify